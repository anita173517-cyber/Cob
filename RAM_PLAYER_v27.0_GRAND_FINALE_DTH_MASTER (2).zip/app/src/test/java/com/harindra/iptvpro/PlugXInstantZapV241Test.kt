package com.harindra.iptvpro

import okhttp3.Protocol
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for RAM PLAYER v24.1 PlugX Instant-Zap Engine:
 * - OkHttp streamClient supports HTTP/2 + HTTP/1.1 multiplexing with 10s/25s timeouts
 * - BufferProfile.PLUGX_INSTANT_ZAP matches PlugX SuperTV low-latency thresholds
 */
class PlugXInstantZapV241Test {

    @Test
    fun streamClientSupportsHttp2AndHttp11WithPlugxTimeouts() {
        val client = NetworkClient.streamClient
        assertTrue(client.protocols.contains(Protocol.HTTP_2))
        assertTrue(client.protocols.contains(Protocol.HTTP_1_1))
        assertEquals(10_000, client.connectTimeoutMillis)
        assertEquals(25_000, client.readTimeoutMillis)
    }

    @Test
    fun plugxInstantZapBufferProfileMatchesLowLatencyBounds() {
        val bp = BufferProfile.fromId("PLUGX_INSTANT", isLowRamDevice = true)
        assertEquals(BufferProfile.PLUGX_INSTANT_ZAP, bp)
        assertEquals(1000, bp.minBufferMs)
        assertEquals(6000, bp.maxBufferMs)
        assertEquals(250, bp.playBufferMs)
        assertEquals(750, bp.rebufferMs)
        assertEquals(6 * 1024 * 1024, bp.targetBytes)
        assertTrue(bp.prioritizeTimeOverSize)
    }

    @Test
    fun defaultBufferProfileIsPlugxInstantZap() {
        assertEquals(BufferProfile.ULTRA_40S, BufferProfile.fromId(null, isLowRamDevice = true))
        assertEquals(BufferProfile.ULTRA_40S, BufferProfile.fromId(null, isLowRamDevice = false))
    }
}
