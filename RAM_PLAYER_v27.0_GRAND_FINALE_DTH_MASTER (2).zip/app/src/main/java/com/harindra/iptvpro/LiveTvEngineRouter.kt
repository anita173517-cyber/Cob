package com.harindra.iptvpro

import java.util.Locale

/**
 * RAM PLAYER v23.2 OTT-ENGINE MASTER EDITION — Live TV Playback Engine Mode.
 * Mirrors OTT Navigator's dual-engine (ExoPlayer + LibVLC HW/SW) architecture for Live TV.
 */
enum class LiveTvEngineMode(val id: String, val displayLabel: String) {
    AUTO_OTT_HEAL("AUTO", "Auto (Media3 + OTT LibVLC Auto-Heal)"),
    LIBVLC_HW("VLC_HW", "OTT LibVLC (HW + Auto SW)"),
    LIBVLC_SW("VLC_SW", "OTT LibVLC (Software Force)"),
    MEDIA3_ONLY("EXO_ONLY", "Media3 ExoPlayer Only");

    companion object {
        fun fromId(raw: String?): LiveTvEngineMode {
            val clean = raw?.trim()?.uppercase(Locale.ROOT).orEmpty()
            return values().firstOrNull { it.id == clean } ?: AUTO_OTT_HEAL
        }
    }
}

/**
 * Deterministic multi-stage healing progression when a Live TV channel produces a black screen,
 * unsupported AC3/E-AC3/DTS audio, interlaced 1080i50 H.264 stall, or MediaCodec decoder error.
 */
enum class LiveTvHealStage(val shortBadge: String) {
    EXO_PRIMARY("MEDIA3"),
    EXO_BACKUP_FORMAT("MEDIA3-ALT"),
    VLC_HW_PRIMARY("OTT-VLC HW"),
    VLC_SW_PRIMARY("OTT-VLC SW"),
    VLC_HW_BACKUP("OTT-VLC HW ALT"),
    VLC_SW_BACKUP("OTT-VLC SW ALT");

    fun usesLibVlc(): Boolean = this != EXO_PRIMARY && this != EXO_BACKUP_FORMAT
    fun forcesSoftwareDecoder(): Boolean = this == VLC_SW_PRIMARY || this == VLC_SW_BACKUP
    fun usesBackupUrl(): Boolean = this == EXO_BACKUP_FORMAT || this == VLC_HW_BACKUP || this == VLC_SW_BACKUP
}

/**
 * Pure-Kotlin Live TV codec intelligence, Xtream URL format switcher, and dual-engine auto-healer.
 * 100% JVM unit-testable with zero Android framework dependencies.
 */
object LiveTvEngineRouter {

    private val PROBLEMATIC_AUDIO_MIMES = setOf(
        "audio/ac3",
        "audio/eac3",
        "audio/eac3-joc",
        "audio/ac4",
        "audio/vnd.dts",
        "audio/vnd.dts.hd",
        "audio/vnd.dts.hd;profile=lbr",
        "audio/vnd.dts.uhd",
        "audio/true-hd",
        "audio/mpeg-l2",
        "audio/mpeg-l1"
    )

    private val PROBLEMATIC_AUDIO_CODEC_TOKENS = listOf(
        "ac-3", "ac3", "ec-3", "eac3", "ac-4", "dts", "dtsc", "dtse", "dtsh", "dtsl", "mlpa", "truehd", "mp2"
    )

    private val PROBLEMATIC_VIDEO_MIMES = setOf(
        "video/mpeg2",
        "video/mp2t",
        "video/wvc1",
        "video/x-ms-wmv",
        "video/mp4v-es",
        "video/mpeg"
    )

    fun isProblematicAudioCodec(mimeType: String?, codecs: String?, channelCount: Int = 0): Boolean {
        val m = mimeType?.trim()?.lowercase(Locale.ROOT).orEmpty()
        if (m in PROBLEMATIC_AUDIO_MIMES) return true
        val c = codecs?.trim()?.lowercase(Locale.ROOT).orEmpty()
        if (c.isNotEmpty() && PROBLEMATIC_AUDIO_CODEC_TOKENS.any { tok -> c.contains(tok) }) {
            return true
        }
        return channelCount >= 6 && (m.contains("ac3") || m.contains("eac3") || m.contains("dts"))
    }

    fun isProblematicVideoCodec(mimeType: String?, codecs: String?): Boolean {
        val m = mimeType?.trim()?.lowercase(Locale.ROOT).orEmpty()
        if (m in PROBLEMATIC_VIDEO_MIMES) return true
        val c = codecs?.trim()?.lowercase(Locale.ROOT).orEmpty()
        return c.startsWith("mp2v") || c.startsWith("mpeg2") || c.startsWith("wvc1")
    }

    fun resolveInitialEngineForChannel(
        globalMode: LiveTvEngineMode,
        rememberedChannelEngineId: String?
    ): LiveTvEngineMode {
        if (globalMode != LiveTvEngineMode.AUTO_OTT_HEAL) {
            return globalMode
        }
        val remembered = rememberedChannelEngineId?.trim()?.uppercase(Locale.ROOT).orEmpty()
        return when (remembered) {
            LiveTvEngineMode.LIBVLC_HW.id -> LiveTvEngineMode.LIBVLC_HW
            LiveTvEngineMode.LIBVLC_SW.id -> LiveTvEngineMode.LIBVLC_SW
            else -> LiveTvEngineMode.AUTO_OTT_HEAL
        }
    }

    fun shouldProactivelySwitchToLibVlc(
        hasUnsupportedVideoTrack: Boolean,
        hasUnsupportedAudioTrack: Boolean,
        audioMimeType: String?,
        audioCodecs: String?,
        audioChannelCount: Int,
        audioDecoderError: String?,
        audioOutputError: String?,
        engineMode: LiveTvEngineMode
    ): Boolean {
        if (engineMode == LiveTvEngineMode.MEDIA3_ONLY) return false
        if (engineMode == LiveTvEngineMode.LIBVLC_HW || engineMode == LiveTvEngineMode.LIBVLC_SW) return true
        if (hasUnsupportedVideoTrack || hasUnsupportedAudioTrack) return true
        val isProblemAudio = isProblematicAudioCodec(audioMimeType, audioCodecs, audioChannelCount)
        if (isProblemAudio && audioChannelCount >= 6) {
            // Indian HD AC3/E-AC3/DTS 5.1 (6ch) channels: switch in 1 shot to OTT-VLC HW (Hardware video + FFmpeg audio)
            return true
        }
        val hasAudioError = !audioDecoderError.isNullOrBlank() || !audioOutputError.isNullOrBlank()
        if (hasAudioError && isProblemAudio) {
            return true
        }
        return false
    }

    fun shouldSwitchToLibVlcOnError(
        errorCodeName: String?,
        message: String?,
        engineMode: LiveTvEngineMode
    ): Boolean {
        if (engineMode == LiveTvEngineMode.MEDIA3_ONLY) return false
        val name = errorCodeName?.uppercase(Locale.ROOT).orEmpty()
        val msg = message?.lowercase(Locale.ROOT).orEmpty()
        if (name.contains("DECODING") ||
            name.contains("DECODER") ||
            name.contains("AUDIO_TRACK") ||
            name.contains("PARSING_CONTAINER") ||
            name.contains("PARSING_MANIFEST") ||
            name.contains("UNSUPPORTED")
        ) {
            return true
        }
        return msg.contains("mediacodec") ||
            msg.contains("decoder") ||
            msg.contains("ac3") ||
            msg.contains("eac3") ||
            msg.contains("dts") ||
            msg.contains("audiotrack") ||
            msg.contains("unrecognizedinputformat") ||
            msg.contains("no suitable")
    }

    fun nextHealStage(
        current: LiveTvHealStage,
        hasBackupUrl: Boolean,
        engineMode: LiveTvEngineMode
    ): LiveTvHealStage? {
        if (engineMode == LiveTvEngineMode.MEDIA3_ONLY) {
            return when (current) {
                LiveTvHealStage.EXO_PRIMARY -> if (hasBackupUrl) LiveTvHealStage.EXO_BACKUP_FORMAT else null
                else -> null
            }
        }
        return when (current) {
            LiveTvHealStage.EXO_PRIMARY -> LiveTvHealStage.VLC_HW_PRIMARY
            LiveTvHealStage.EXO_BACKUP_FORMAT -> LiveTvHealStage.VLC_HW_PRIMARY
            LiveTvHealStage.VLC_HW_PRIMARY -> if (hasBackupUrl) LiveTvHealStage.VLC_HW_BACKUP else null
            LiveTvHealStage.VLC_SW_PRIMARY -> if (hasBackupUrl) LiveTvHealStage.VLC_SW_BACKUP else null
            LiveTvHealStage.VLC_HW_BACKUP -> null
            LiveTvHealStage.VLC_SW_BACKUP -> null
        }
    }

    /**
     * Generates an alternate Xtream Live TV stream URL (.m3u8 <-> .ts) when the channel
     * doesn't already carry an explicit backupUrl, matching OTT Navigator's format fallback.
     */
    fun buildAlternativeXtreamUrl(url: String, existingBackupUrl: String = ""): String {
        val explicit = existingBackupUrl.trim()
        if (explicit.isNotEmpty() && !explicit.equals(url.trim(), ignoreCase = true)) {
            return explicit
        }
        val clean = url.trim()
        if (clean.isEmpty()) return ""
        val qIdx = clean.indexOf('?')
        val basePart = if (qIdx >= 0) clean.substring(0, qIdx) else clean
        val queryPart = if (qIdx >= 0) clean.substring(qIdx) else ""
        val lowerBase = basePart.lowercase(Locale.ROOT)
        return when {
            lowerBase.endsWith(".m3u8") -> basePart.dropLast(5) + ".ts" + queryPart
            lowerBase.endsWith(".ts") -> basePart.dropLast(3) + ".m3u8" + queryPart
            else -> ""
        }
    }
}
