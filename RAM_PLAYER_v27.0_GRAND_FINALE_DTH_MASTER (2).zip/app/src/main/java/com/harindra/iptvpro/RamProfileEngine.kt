package com.harindra.iptvpro

import android.content.Context
import android.view.View

/**
 * RAM PLAYER v26.0 — SMART RAM PROFILE & 3D ANIMATION ENGINE (Section 13).
 *
 * User-selectable 4-tier Device Performance Profile:
 * - 512MB RAM: Ultra Lite Mode — 0ms animations, maximum speed, lowest RAM footprint
 * - 1GB RAM:   Lite Mode — subtle 80ms smooth focus transitions
 * - 2GB RAM:   Balanced Mode — 140ms smooth effects, elevation & soft focus glow
 * - 4GB+ RAM:  Ultra Premium 3D Mode — 200ms 3D perspective depth tilt, glass depth & smooth transitions
 */
enum class RamProfileMode(
    val id: String,
    val shortLabel: String,
    val title: String,
    val subtitle: String,
    val animationDurationMs: Long,
    val focusScale: Float,
    val enable3dTilt: Boolean,
    val enableGlassDepth: Boolean,
    val focusElevationDp: Float
) {
    RAM_512MB_ULTRA_LITE(
        id = "RAM_512MB",
        shortLabel = "512MB Ultra Lite",
        title = "512MB RAM — Ultra Lite Mode",
        subtitle = "Zero heavy animations • Instant D-Pad response • Maximum speed on 512MB TVs",
        animationDurationMs = 0L,
        focusScale = 1.0f,
        enable3dTilt = false,
        enableGlassDepth = false,
        focusElevationDp = 0f
    ),
    RAM_1GB_LITE(
        id = "RAM_1GB",
        shortLabel = "1GB Lite",
        title = "1GB RAM — Lite Mode",
        subtitle = "Lightweight 80ms smooth focus transitions • Optimized for 1GB TVs",
        animationDurationMs = 80L,
        focusScale = 1.02f,
        enable3dTilt = false,
        enableGlassDepth = false,
        focusElevationDp = 3f
    ),
    RAM_2GB_BALANCED(
        id = "RAM_2GB",
        shortLabel = "2GB Balanced",
        title = "2GB RAM — Balanced Mode",
        subtitle = "Smooth 140ms animations, crisp focus glow & balanced performance",
        animationDurationMs = 140L,
        focusScale = 1.045f,
        enable3dTilt = false,
        enableGlassDepth = true,
        focusElevationDp = 6f
    ),
    RAM_4GB_ULTRA_3D(
        id = "RAM_4GB_3D",
        shortLabel = "4GB+ Ultra 3D",
        title = "4GB+ RAM — Ultra Premium 3D Mode",
        subtitle = "3D perspective depth tilt, glass depth, smooth 200ms transitions & premium D2H feel",
        animationDurationMs = 200L,
        focusScale = 1.07f,
        enable3dTilt = true,
        enableGlassDepth = true,
        focusElevationDp = 12f
    );

    companion object {
        private const val PREF_FILE = "iptv_pro_prefs"
        private const val KEY_RAM_PROFILE = "ram_profile_mode_v26"

        fun fromId(id: String?): RamProfileMode? {
            if (id.isNullOrBlank()) return null
            return values().firstOrNull { it.id.equals(id.trim(), ignoreCase = true) }
        }

        fun recommendedForRamMb(totalRamMb: Long): RamProfileMode {
            return when {
                totalRamMb <= 768L -> RAM_512MB_ULTRA_LITE
                totalRamMb <= 1536L -> RAM_1GB_LITE
                totalRamMb <= 3072L -> RAM_2GB_BALANCED
                else -> RAM_4GB_ULTRA_3D
            }
        }

        fun loadSaved(context: Context, totalRamMb: Long): RamProfileMode {
            val saved = context.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE)
                .getString(KEY_RAM_PROFILE, null)
            return fromId(saved) ?: recommendedForRamMb(totalRamMb)
        }

        fun save(context: Context, mode: RamProfileMode) {
            context.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_RAM_PROFILE, mode.id)
                .apply()
        }

        fun applyFocusEffect(view: View, hasFocus: Boolean, mode: RamProfileMode) {
            view.animate().cancel()
            val scale = if (hasFocus) mode.focusScale else 1.0f
            val elev = if (hasFocus) mode.focusElevationDp * view.resources.displayMetrics.density else 0f
            val rotY = if (hasFocus && mode.enable3dTilt) -3.5f else 0f
            val transZ = if (hasFocus && mode.enable3dTilt) 8f * view.resources.displayMetrics.density else 0f

            if (mode.animationDurationMs <= 0L) {
                view.scaleX = scale
                view.scaleY = scale
                view.rotationY = rotY
                view.translationZ = transZ
                view.elevation = elev
            } else {
                if (mode.enable3dTilt) {
                    view.cameraDistance = 6000f * view.resources.displayMetrics.density
                }
                view.animate()
                    .scaleX(scale)
                    .scaleY(scale)
                    .rotationY(rotY)
                    .translationZ(transZ)
                    .setDuration(mode.animationDurationMs)
                    .start()
                view.elevation = elev
            }
        }

        fun animatePanelVisibility(panel: View, show: Boolean, mode: RamProfileMode, onEnd: (() -> Unit)? = null) {
            panel.animate().cancel()
            if (mode.animationDurationMs <= 0L) {
                panel.alpha = 1f
                panel.translationX = 0f
                panel.visibility = if (show) View.VISIBLE else View.GONE
                onEnd?.invoke()
                return
            }
            val slidePx = -28f * panel.resources.displayMetrics.density
            if (show) {
                panel.alpha = 0f
                panel.translationX = if (mode.enableGlassDepth) slidePx else 0f
                panel.visibility = View.VISIBLE
                panel.animate()
                    .alpha(1f)
                    .translationX(0f)
                    .setDuration(mode.animationDurationMs)
                    .withEndAction { onEnd?.invoke() }
                    .start()
            } else {
                panel.animate()
                    .alpha(0f)
                    .translationX(if (mode.enableGlassDepth) slidePx else 0f)
                    .setDuration((mode.animationDurationMs * 3L) / 4L)
                    .withEndAction {
                        panel.visibility = View.GONE
                        panel.alpha = 1f
                        panel.translationX = 0f
                        onEnd?.invoke()
                    }
                    .start()
            }
        }
    }
}
